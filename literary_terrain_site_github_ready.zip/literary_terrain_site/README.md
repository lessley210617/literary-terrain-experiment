# 文学地形图构建实验网站

上传到 GitHub 时，请保持这个结构不变：

index.html
assets/
  image_001.jpg
  image_002.jpg
  ...

不要只上传 index.html，否则图片翻页会失效。
